package controlP5;

class ColorPalette extends ControlGroup< ColorPalette > {

	protected ColorPalette( ControlP5 theControlP5 , ControllerGroup< ? > theParent , String theName , int theX , int theY , int theWidth , int theHeight ) {
		super( theControlP5 , theParent , theName , theX , theY , theWidth , theHeight );
	}
}
