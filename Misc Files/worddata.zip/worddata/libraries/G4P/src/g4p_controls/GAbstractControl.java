/*
  Part of the G4P library for Processing 
  	http://www.lagers.org.uk/g4p/index.html
	http://sourceforge.net/projects/g4p/files/?source=navbar

  Copyright (c) Peter Lager 2008

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
 */

package g4p_controls;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import processing.awt.PGraphicsJava2D;
import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PGraphics;
import processing.event.KeyEvent;
import processing.event.MouseEvent;

/**
 * Abstract base class for all GUI controls.
 * 
 * @author Peter Lager
 *
 */
public abstract class GAbstractControl implements PConstants, GConstants, GConstantsInternal {

	/*
	 * INTERNAL USE ONLY This holds a reference to the Gcontrol that currently has
	 * the focus. A control loses focus when another control takes focus with the
	 * takeFocus() method. The takeFocus method should use focusIsWith.loseFocus()
	 * before setting its value to the new control.
	 */
	static GAbstractControl focusIsWith = null;

	/*
	 * INTERNAL USE ONLY Use by the tab manager to move focus between controls
	 * 
	 */
	static GAbstractControl controlToTakeFocus = null;

	/*
	 * INTERNAL USE ONLY Keeps track of the control the mouse is over so the mouse
	 * cursor can be changed if we wish.
	 */
	static GAbstractControl cursorIsOver;

	// Reference to the PApplet object that owns this control
	protected PApplet winApp;

	/* Used to when controls overlap */
	protected int z = Z_STICKY;

	// Set to true when mouse is dragging : set false on button released
	protected boolean dragging = false;

	protected static float epsilon = 0.001f;

	/** Link to the parent panel (if null then it is on main window) */
	protected GAbstractControl parent = null;

	// A list of child GControls added to this control
	protected LinkedList<GAbstractControl> children = null;
	protected boolean allowChildren = true;

	protected int localColorScheme = G4P.globalColorScheme;
	protected Color[] palette = null;
	protected int alphaLevel = G4P.globalAlpha;

	/**
	 * Top left position of control in pixels (relative to parent or absolute if
	 * parent is null) (changed form int data type in V3
	 */
	protected float x, y;
	/**
	 * Width and height of control in pixels for drawing background (changed form
	 * int data type in V3
	 */
	protected float width, height;
	/** Half sizes reduces programming complexity later */
	protected float halfWidth, halfHeight;
	/** The centre of the control */
	protected float cx, cy;
	/** The angle to control is rotated (radians) */
	protected float rotAngle;
	/** Introduced V3 to speed up AffineTransform operations */
	protected double[] temp = new double[2];

	// New to V3 controls have an image buffer which is only redrawn if
	// it has been invalidated
	protected PGraphicsJava2D buffer = null;
	protected boolean bufferInvalid = true;

	/** Whether to show background or not */
	protected boolean opaque = false;

	// The cursor image when over a control
	// This should be set in the controls constructor
	protected int cursorOver = HAND;

	/*
	 * Position over control corrected for any transformation. <br> [0,0] is top
	 * left corner of the control. This is used to determine the mouse position over
	 * any particular control or part of a control.
	 */
	protected float ox, oy;

	/** Simple tag that can be used by the user */
	public String tag = "";

	/** Allows user to specify a number for this control */
	public int tagNo;

	/* Is the control visible or not */
	boolean visible = true;

	/* Is the control enabled to generate mouse and keyboard events */
	boolean enabled = true;

	/*
	 * Is the control available for mouse and keyboard events. This is only used
	 * internally to prevent user input being processed during animation. It will
	 * preserve enabled and visible flags
	 */
	boolean available = true;

	/* The object to handle the event */
	protected Object eventHandlerObject = null;
	/* The method in eventHandlerObject to execute */
	protected Method eventHandlerMethod = null;
	/* the name of the method to handle the event */
	protected String eventHandlerMethodName;

	protected int registeredMethods = 0;

	// Tooltip V4.3.9
	protected GToolTip tip = null;
	protected boolean allowToolTips = true;

	/**
	 * Base constructor for ALL control ctors that do not have a visible UI but
	 * require access to a PApplet object. <br>
	 * As of V3.5 the only class using this constructor is GGroup
	 * 
	 * @param theApplet the main sketch or GWindow control for this control
	 */
	public GAbstractControl(PApplet theApplet) {
		G4P.registerSketch(theApplet);
		winApp = theApplet;
		GCScheme.makeColorSchemes(winApp);
		rotAngle = 0;
		z = 0;
		palette = GCScheme.getJavaColor(localColorScheme);
	}

	/**
	 * Base constructor for ALL control ctors that have a visible UI but whose width
	 * and height are determined elsewhere e.g. the size of an image. It will set
	 * the position of the control based on controlMode. <br>
	 * 
	 * @param theApplet the main sketch or GWindow control for this control
	 * @param p0        x position based on control mode
	 * @param p1        y position based on control mode
	 */
	public GAbstractControl(PApplet theApplet, float p0, float p1) {
		this(theApplet);
		switch (G4P.control_mode) {
		case CORNER: // (x,y,w,h)
		case CORNERS: // (x0,y0,x1,y1)
			x = p0;
			y = p1;
			break;
		case CENTER: // (cx,cy,w,h)
			cx = p0;
			cy = p1;
			break;
		}
	}

	/**
	 * Base constructor for ALL control ctors that have a visible UI. It will set
	 * the position and size of the control based on controlMode. <br>
	 * 
	 * @param theApplet the main sketch or GWindow control for this control
	 * @param p0        x position based on control mode
	 * @param p1        y position based on control mode
	 * @param p2        x position or width based on control mode
	 * @param p3        y position or height based on control mode
	 */
	public GAbstractControl(PApplet theApplet, float p0, float p1, float p2, float p3) {
		this(theApplet);
		setPositionAndSize(p0, p1, p2, p3);
	}

	/**
	 * Make a 2D off-screen buffer for this control.
	 */
	protected void makeBuffer() {
		buffer = (PGraphicsJava2D) winApp.createGraphics((int) width, (int) height, PApplet.JAVA2D);
		buffer.rectMode(PApplet.CORNER);
		buffer.beginDraw();
		buffer.endDraw();
//		setTextRenderingHints((Graphics2D) buffer.getNative(), 1);
	}

	// May not need this method needs to be called in updateBuffer
	protected void setTextRenderingHints(Graphics2D g2d, int hint) {
		// Attempt to fix antialiasing
		if (hint == 0) {
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
			return;
		}
		// Switch on antialiasing
		// Select hint type
		switch (hint) {
		case 1:
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			break;
		case 2:
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_GASP);
			break;
		case 3:
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
			break;
		default:
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
			break;

		}
	}

	/**
	 * Calculate all the variables that determine the position and size of the
	 * control. This depends on
	 * 
	 * <pre>
	 * control_mode
	 * </pre>
	 * 
	 */
	private void setPositionAndSize(float n0, float n1, float n2, float n3) {
		switch (G4P.control_mode) {
		case CORNER: // (x,y,w,h)
			x = n0;
			y = n1;
			width = n2;
			height = n3;
			halfWidth = width / 2;
			halfHeight = height / 2;
			cx = x + halfWidth;
			cy = y + halfHeight;
			break;
		case CORNERS: // (x0,y0,x1,y1)
			x = n0;
			y = n1;
			width = n2 - n0;
			height = n3 - n1;
			halfWidth = width / 2;
			halfHeight = height / 2;
			cx = x + halfWidth;
			cy = y + halfHeight;
			break;
		case CENTER: // (cx,cy,w,h)
			cx = n0;
			cy = n1;
			width = n2;
			height = n3;
			halfWidth = width / 2;
			halfHeight = height / 2;
			x = cx - halfWidth;
			y = cy - halfHeight;
			break;
		}
	}

	// The following methods were introduced in V4.3.9 to manage tool tips

	/**
	 * Replaces the current tool tip (if any) with a new tool tip for this control.
	 * Do not use this method to simply change the tip text, in that situation use
	 * the setToolTipText(String) method.
	 * 
	 * @param text the text to display
	 * @param dx   horizontal distance between the top-left corner of the tool tip
	 *             and the top-left corner of the control
	 * @param dy   vertical distance between the top-left corner of the tool tip and
	 *             the top-left corner of the control
	 */
	public void setTip(String text, float dx, float dy) {
		if (!this.allowToolTips) {
			System.err.println(this.getClass().getSimpleName() + " controls do not support tool tips!");
			return;
		}
		removeTip();
		tip = new GToolTip(winApp, 0, 0, 1000, 60, text);
		setTipImpl(dx, dy);
	}

	/**
	 * Only use this method if you are creating custom tool tips. <br/>
	 * 
	 * Replaces the current tool tip (if any) with a new tool tip for this control.
	 * Do not use this method to simply change the tip text, in that situation use
	 * the setToolTipText(String) method.
	 * 
	 * @param tt the custom tool tip
	 * @param dx horizontal distance between the top-left corner of the tool tip and
	 *           the top-left corner of the control
	 * @param dy vertical distance between the top-left corner of the tool tip and
	 *           the top-left corner of the control
	 */
	public void setTip(GToolTip tt, float dx, float dy) {
		if (!this.allowToolTips) {
			System.err.println(this.getClass().getSimpleName() + " controls do not support tool tips!");
			return;
		}
		removeTip();
		tip = tt;
		setTipImpl(dx, dy);
	}

	/**
	 * Replaces the current tool tip (if any) with a new tool tip for this control.
	 * Do not use this method to simply change the tip text, in that situation use
	 * the setTipText(String) method.
	 * 
	 * @param text the text to display
	 * @param ax   horizontal alignment with its control
	 * @param ay   vertical position relative with its control
	 * @param gap  the gap between the tool tip and its control in pixels
	 */
	public void setTip(String text, GAlign ax, GAlign ay, float gap) {
		if (!this.allowToolTips) {
			System.err.println(this.getClass().getSimpleName() + " controls do not support tool tips!");
			return;
		}
		removeTip();
		tip = new GToolTip(winApp, 0, 0, 1000, 60, text);
		setTipImpl(ax, ay, gap);
	}

	/**
	 * Only use this method if you are creating custom tool tips. <br/>
	 * 
	 * Replaces the current tool tip (if any) with a new tool tip for this control.
	 * Do not use this method to simply change the tip text, in that situation use
	 * the setTipText(String) method.
	 * 
	 * @param tt  the custom tool tip
	 * @param ax  horizontal alignment with its control
	 * @param ay  vertical position relative with its control
	 * @param gap the gap between the tool tip and its control in pixels
	 */
	public void setTip(GToolTip tt, GAlign ax, GAlign ay, float gap) {
		if (!this.allowToolTips) {
			System.err.println(this.getClass().getSimpleName() + " controls do not support tool tips!");
			return;
		}
		removeTip();
		tip = tt;
		setTipImpl(ax, ay, gap);
	}

	/**
	 * Implementation method to set a tool tip
	 */
	private void setTipImpl(float dx, float dy) {
		tip.parent = this;
		tip.setLocalColorScheme(localColorScheme);
		addControlImpl(tip, dx, dy, 0);
		hideTip();
	}

	/**
	 * Implementation method to set a tool tip
	 */
	private void setTipImpl(GAlign ax, GAlign ay, float gap) {
		tip.parent = this;
		tip.setLocalColorScheme(localColorScheme);
		addControlImpl(tip, 0, 0, 0);
		float dx, dy;
		switch (ax) {
		case CENTER:
			dx = (width - tip.width) / 2;
			break;
		case RIGHT:
			dx = width - tip.width;
			break;
		case LEFT:
		default:
			dx = 0;
			break;
		}
		switch (ay) {
		case SOUTH:
			dy = height + gap;
			break;
		case NORTH:
		default:
			dy = -(tip.height + gap);
			break;
		}
		tip.moveTo(dx, dy);
		hideTip();
	}

	/**
	 * If this control has a tool tip change the text it displays.
	 * 
	 * @param text the text to display
	 */
	public void setTipText(String text) {
		if (tip != null)
			tip.setText(text);
	}

	/**
	 * Removes the existing tool tip for this control.
	 */
	public void removeTip() {
		if (tip != null) {
			children.remove(tip); // remove from child list
			tip.dispose(); // remove from control list at next post()
			tip = null; // clear the reference
		}
	}

	/**
	 * Set the maximum length of time to show the tool tip
	 * 
	 * @param msecs
	 */
	public void setTipDisplayTime(long msecs) {
		if (tip != null)
			tip.showtime = msecs;
	}

	/**
	 * By default the tool tip is always aligned along the X axis. To have the tool
	 * tip rotate with the control pass false.
	 * 
	 * @param level false to rotate with the control else false to keep horizontal
	 */
	public void setTipHorz(boolean level) {
		if (tip != null) { // && tip.keepHorizontal != level) {
			tip.keepHorizontal = level;
			tip.rotAngle = level ? -rotAngle : 0;
		}
	}

	/**
	 * Gets a reference to the tool tip so the user can access methods not available
	 * through its control.
	 * 
	 * @return the tool tip
	 */
	public GToolTip getTip() {
		return tip;
	}

	/**
	 * Show the tool tip. Called when mouse enters control.
	 */
	protected void showTip() {
		if (tip != null) {
			tip.setVisible(true);
			tip.tiptime = System.currentTimeMillis();
		}
	}

	/**
	 * Hide the tool tip. Called when mouse exits control or display time exceeded.
	 */
	protected void hideTip() {
		if (tip != null) {
			tip.setVisible(false);
			tip.tiptime = 0;
		}
	}

	/**
	 * Used internally at runtime to show/hide the tool tip. V4.3.9
	 */
	protected void manageToolTip() {
		if (currSpot >= 0 && currSpot != lastSpot) {
			showTip();
			lastSpot = currSpot;
		} else if (lastSpot >= 0 && currSpot < 0) {
			hideTip();
			lastSpot = -1;
		}
		lastSpot = currSpot;
	}

	/**
	 * Used internally to enforce minimum size constraints
	 * 
	 * @param w the new width
	 * @param h the new height
	 */
	protected void resize(int w, int h) {
		width = w;
		height = h;
		halfWidth = width / 2;
		halfHeight = height / 2;
		switch (G4P.control_mode) {
		case CORNER: // (x,y,w,h)
		case CORNERS: // (x0,y0,x1,y1)
			cx = x + halfWidth;
			cy = y + halfHeight;
			break;
		case CENTER: // (cx,cy,w,h)
			x = cx - halfWidth;
			y = cy - halfHeight;
			break;
		}
		buffer = (PGraphicsJava2D) winApp.createGraphics(w, h, PApplet.JAVA2D);
		buffer.rectMode(PApplet.CORNER);
	}

	/**
	 * If the control responds to key or mouse input or has a visual representation
	 * this it can be part of a group controller.
	 * 
	 * @param control the G4P control we are interested in
	 * @return true if it can be added to a group controller
	 */
	protected boolean isSuitableForGroupControl(GAbstractControl control) {
		return (GROUP_CONTROL_METHOD & registeredMethods) != 0;
	}

	/**
	 * Introduced in V4..3.9 along with tool tips
	 */
	protected void drawChildren() {
		if (children != null) {
			for (GAbstractControl c : children)
				c.draw();
		}
	}

	/*
	 * These are empty methods to enable polymorphism
	 */
	public void draw() {
	}

	public void mouseEvent(MouseEvent event) {
	}

	public void keyEvent(KeyEvent e) {
	}

	public void pre() {
	}

	public void post() {
	}

	/**
	 * This will remove all references to this control from G4P after the next frame
	 * has been rendered. <br>
	 * The user is responsible for nullifying all references to this control in
	 * their sketch code. <br>
	 * Once this method is called the control cannot be reused but resources used by
	 * the control remain until ALL references to the control are set to null.<br>
	 * For example if you want to dispose of a button called
	 * 
	 * <pre>
	 * btnDoThis
	 * </pre>
	 * 
	 * then to remove the button use the statements <br>
	 * 
	 * <pre>
	 * btnDoThis.dispose(); <br>
	 * btnDoThis = null; <br>
	 * </pre>
	 * 
	 */
	public void dispose() {
		G4P.removeControl(this);
	}

	/**
	 * <b>This is for emergency use only!!!! </b> <br>
	 * In this version of the library a visual controls is drawn to off-screen
	 * buffer and then drawn to the screen by copying the buffer. This means that
	 * the computationally expensive routines needed to draw the control (especially
	 * text controls) are only done when a change has been noted. This means that
	 * single changes need not trigger a full redraw to buffer. <br>
	 * It does mean that an error in the library code could result in the buffer not
	 * being updated after changes. If this happens then in draw() call this method
	 * on the affected control, and report it as an issue
	 * <a href = 'https://sourceforge.net/p/g4p/tickets/?source=navbar'>here</a>
	 * <br>
	 * Thanks
	 */
	public void forceBufferUpdate() {
		bufferInvalid = true;
	}

	protected HotSpot[] hotspots = null;
	protected int currSpot = -1;
	protected int lastSpot = -1;

	/**
	 * Stop when we are over a hotspot. <br>
	 * Hotspots should be listed in order of importance.
	 * 
	 * @param px
	 * @param py
	 * @return the index for the first hotspot containing [px,py] else return -1
	 */
	protected int whichHotSpot(float px, float py) {
		if (hotspots == null)
			return -1;
		int hs = -1;
		for (int i = 0; i < hotspots.length; i++) {
			if (hotspots[i].contains(px, py)) {
				hs = hotspots[i].id;
				break;
			}
		}
		return hs;
	}

	protected int getCurrHotSpot() {
		return currSpot;
	}

	/**
	 * Change a specific colour within the scheme. <br>
	 * Most controls used a shared colour palette but calling this method will
	 * create a new palette specific for this control.
	 * 
	 * @param colorNo the colour index value (0-15 inlc)
	 * @param color   ARGB color value
	 */
	public void setLocalColor(int colorNo, int color) {
		// If necessary make a duplicate of the current color scheme
		if (localColorScheme >= 0) {
			int[] colors = GCScheme.getPalette(localColorScheme);
			palette = new Color[16];
			for (int i = 0; i < 16; i++)
				palette[i] = new Color(colors[i], true); // keep alpha
			localColorScheme = -1;
		}
		colorNo = Math.abs(colorNo) % 16;
		palette[colorNo] = new Color(color, true); // keep alpha;
		bufferInvalid = true;
	}

	/**
	 * Set the local colour scheme for this control. Children are ignored.
	 * 
	 * @param cs the colour scheme to use (0-15 incl.)
	 */
	public void setLocalColorScheme(int cs) {
		setLocalColorScheme(cs, false);
	}

	/**
	 * Set the local colour scheme for this control. If required include the
	 * children and their children.
	 * 
	 * @param cs              the colour scheme to use (0-15 incl.)
	 * @param includeChildren if do do the same for all descendants
	 */
	public void setLocalColorScheme(int cs, boolean includeChildren) {
		cs = Math.abs(cs) % 16; // Force into valid range
		if (localColorScheme != cs || palette == null) {
			localColorScheme = cs;
			palette = GCScheme.getJavaColor(localColorScheme);
			bufferInvalid = true;
			if (includeChildren && children != null) {
				for (GAbstractControl c : children)
					c.setLocalColorScheme(cs, true);
			}
		}
	}

	/**
	 * Get the local color scheme ID number. If it returns a value &lt;0 then it is
	 * using a control specific palette.
	 * 
	 * @return local colour scheme ID
	 */
	public int getLocalColorScheme() {
		return localColorScheme;
	}

	/**
	 * Set the transparency of the control and make it unavailable to mouse and
	 * keyboard events if below the threshold. Child controls are ignored?
	 * 
	 * @param alpha value in the range 0 (transparent) to 255 (opaque)
	 */
	public void setAlpha(int alpha) {
		alpha = Math.abs(alpha) % 256;
		if (alphaLevel != alpha) {
			alphaLevel = alpha;
			available = (alphaLevel >= ALPHA_BLOCK);
			bufferInvalid = true;
		}
	}

	/**
	 * Set the transparency of the control and make it unavailable to mouse and
	 * keyboard events if below the threshold. Child controls are ignored? <br>
	 * If required include the children and their children.
	 * 
	 * @param alpha           value in the range 0 (transparent) to 255 (opaque)
	 * @param includeChildren if do do the same for all descendants
	 */
	public void setAlpha(int alpha, boolean includeChildren) {
		setAlpha(alpha);
		if (includeChildren && children != null) {
			for (GAbstractControl c : children)
				c.setAlpha(alpha, true);
		}
	}

	/**
	 * Returns the current transparency level <br>
	 * 0 = fully transparent <br>
	 * 255 = opaque <br>
	 * 
	 * @return alpha level
	 */
	public int getAlpha() {
		return alphaLevel;
	}

	/**
	 * Get the parent control. If null then this is a top-level control
	 * 
	 * @return return parent control, or null if top level
	 */
	public GAbstractControl getParent() {
		return parent;
	}

	/**
	 * @return the PApplet that manages this control
	 */
	public PApplet getPApplet() {
		return winApp;
	}

	// Used by composite control i.e. ones that have scrollbars, buttons etc. but
	// not
	// GWindow and GPanel
	protected PGraphics getBuffer() {
		return buffer;
	}

	/**
	 * Support UTF8 encoding
	 * 
	 * @param ascii UTF8 code
	 * @return true if the character can be displayed
	 */
	protected boolean isDisplayable(int ascii) {
		return !(ascii < 32 || ascii == 127);
	}

	/**
	 * Save a snapshot of the control using class name and sketch runtime as the
	 * filename
	 * 
	 * @return true if the snapshot was saved else return false
	 */
	public boolean saveSnapshot() {
		String filename = getClass().getSimpleName().toLowerCase() + "_" + System.currentTimeMillis() + ".png";
		return saveSnapshot(filename);
	}

	/**
	 * Save a snapshot of the control using the specified filename.
	 * 
	 * 
	 * @param filename the name of the file to save for the image
	 * @return true if the snapshot was saved else return false
	 */
	public boolean saveSnapshot(String filename) {
		// This method is overridden in GAbstractView because it doesn't use the buffer
		if (buffer != null) {
			buffer.save(filename);
			return true;
		}
		return false;
	}

	/**
	 * This method should be used sparingly since it is heavy on resources.
	 * 
	 * @return a PGraphics object showing current state of the control (ignoring
	 *         rotation)
	 */
	public PGraphics getSnapshot() {
		if (buffer != null) {
			updateBuffer();
			PGraphics snap = winApp.createGraphics(buffer.width, buffer.height, PApplet.JAVA2D);
			snap.beginDraw();
			snap.image(buffer, 0, 0);
			snap.endDraw();
			return snap;
		}
		return null;
	}

	/*
	 * Empty method at the moment make abstract in final version
	 */
	protected void updateBuffer() {
	}

	/**
	 * Attempt to create the default event handler for the control class. The
	 * default event handler is a method that returns void and has a single
	 * parameter of the same type as the control class generating the event and a
	 * method name specific for that class.
	 * 
	 * @param handlerObj    the object to handle the event
	 * @param methodName    the method to execute in the object handler class
	 * @param param_classes the parameter classes.
	 * @param param_names   that names of the parameters (used for error messages
	 *                      only)
	 */
	@SuppressWarnings("rawtypes")
	protected void createEventHandler(Object handlerObj, String methodName, Class[] param_classes,
			String[] param_names) {
		try {
			eventHandlerMethod = handlerObj.getClass().getMethod(methodName, param_classes);
			eventHandlerObject = handlerObj;
			eventHandlerMethodName = methodName;
		} catch (Exception e) {
			GMessenger.message(MISSING, new Object[] { this, methodName, param_classes, param_names });
			eventHandlerObject = null;
		}
	}

	/**
	 * Attempt to create the default event handler for the control class. The
	 * default event handler is a method that returns void and has a single
	 * parameter of the same type as the control class generating the event and a
	 * method name specific for that class.
	 * 
	 * @param obj        the object to handle the event
	 * @param methodName the method to execute in the object handler class
	 */
	public void addEventHandler(Object obj, String methodName) {
		try {
			eventHandlerObject = obj;
			eventHandlerMethodName = methodName;
			eventHandlerMethod = obj.getClass().getMethod(methodName, new Class<?>[] { this.getClass(), GEvent.class });
		} catch (Exception e) {
			GMessenger.message(NONEXISTANT,
					new Object[] { this, methodName, new Class<?>[] { this.getClass(), GEvent.class } });
			eventHandlerObject = null;
			eventHandlerMethodName = "";
		}
	}

	/**
	 * Attempt to fire an event for this control.
	 * 
	 * The method called must have a single parameter which is the object firing the
	 * event. If the method to be called is to have different parameters then it
	 * should be overridden in the child class The method
	 */
	protected void fireEvent(Object... objects) {
		if (eventHandlerMethod != null) {
			try {
				eventHandlerMethod.invoke(eventHandlerObject, objects);
			} catch (Exception e) {
				GMessenger.message(EXCP_IN_HANDLER, new Object[] { eventHandlerObject, eventHandlerMethodName, e });
			}
		}
	}

	/**
	 * Set the rotation to apply when displaying this control. The center of
	 * rotation is determined by the control_mode attribute.
	 * 
	 * @param angle clockwise angle in radians
	 */
	public void setRotation(float angle) {
		setRotation(angle, G4P.control_mode);
	}

	/**
	 * Set the rotation to apply when displaying this control. The center of
	 * rotation is determined by the mode parameter parameter.
	 * 
	 * @param angle clockwise angle in radians
	 * @param mode  PApplet.CORNER / CORNERS / CENTER
	 */
	public void setRotation(float angle, GControlMode mode) {
		if (tip != null && tip.keepHorizontal)
			tip.rotAngle = -angle;
		rotAngle = angle;
		AffineTransform aff = new AffineTransform();
		aff.setToRotation(angle);
		switch (mode) {
		case CORNER:
		case CORNERS:
			// Rotate about top corner
			temp[0] = halfWidth;
			temp[1] = halfHeight;
			aff.transform(temp, 0, temp, 0, 1);
			cx = (float) temp[0] + x;// - halfWidth;
			cy = (float) temp[1] + y;// - halfHeight;
			break;
		case CENTER:
		default:
			// Rotate about centre
			temp[0] = -halfWidth;
			temp[1] = -halfHeight;
			aff.transform(temp, 0, temp, 0, 1);
			x = cx + (float) temp[0];
			y = cy + (float) temp[1]; // should this be minus?? I don't think so
			break;
		}
	}

	/**
	 * Move the control to the given position based on the mode. <br>
	 * 
	 * The position is not constrained to the screen area. <br>
	 * 
	 * The current control mode determines whether we move the corner or the center
	 * of the control to px,py <br>
	 * 
	 * @param px the horizontal position to move to
	 * @param py the vertical position to move to
	 */
	public void moveTo(float px, float py) {
		moveTo(px, py, G4P.control_mode);
	}

	/**
	 * Move the control to the given position based on the mode. <br>
	 * 
	 * Unlike when dragged the position is not constrained to the screen area. <br>
	 * 
	 * The mode determines whether we move the corner or the center of the control
	 * to px,py <br>
	 * 
	 * @param px   the horizontal position to move to
	 * @param py   the vertical position to move to
	 * @param mode the control mode
	 */
	public void moveTo(float px, float py, GControlMode mode) {
		GAbstractControl p = parent;
		if (p != null) {
			px -= p.width / 2.0f;
			py -= p.height / 2.0f;
		}
		switch (mode) {
		case CORNER:
		case CORNERS:
			cx += (px - x);
			cy += (py - y);
			x = cx - width / 2.0f;
			y = cy - height / 2.0f;
			break;
		case CENTER:
			cx = px;
			cy = py;
			x = cx - width / 2.0f;
			y = cy - height / 2.0f;
			break;
		}
	}

	/**
	 * Get the left position of the control. <br>
	 * If the control is on a panel then the value returned is relative to the
	 * top-left corner of the panel otherwise it is relative to the sketch window
	 * display. <br>
	 * 
	 * @return top-left corner x position
	 */
	public float getX() {
		if (parent != null)
			return x + parent.width / 2.0f;
		else
			return x;
	}

	/**
	 * Get the top position of the control. <br>
	 * If the control is on a panel then the value returned is relative to the
	 * top-left corner of the panel otherwise it is relative to the sketch window
	 * display. <br>
	 * 
	 * @return top-left corner y position
	 */
	public float getY() {
		if (parent != null)
			return y + parent.height / 2.0f;
		else
			return y;
	}

	/**
	 * Get the centre x position of the control. <br>
	 * If the control is on a panel then the value returned is relative to the
	 * top-left corner of the panel otherwise it is relative to the sketch window
	 * display. <br>
	 * 
	 * @return the x position corresponding to the centre of the control.
	 */
	public float getCX() {
		if (parent != null)
			return x + (parent.width + width) / 2.0f;
		else
			return cx;
	}

	/**
	 * Get the centre y position of the control. <br>
	 * If the control is on a panel then the value returned is relative to the
	 * top-left corner of the panel otherwise it is relative to the sketch window
	 * display. <br>
	 * 
	 * @return the y position corresponding to the centre of the control.
	 */
	public float getCY() {
		if (parent != null)
			return x + (parent.width + width) / 2.0f;
		else
			return cy;
	}

	/**
	 * @return the width
	 */
	public float getWidth() {
		return width;
	}

	/**
	 * @return the height
	 */
	public float getHeight() {
		return height;
	}

	/**
	 * 
	 * @param visible the visibility to set
	 */
	public void setVisible(boolean visible) {
		// If we are making it invisible and it has focus give up the focus
		if (!visible && focusIsWith == this)
			loseFocus(parent);
		this.visible = visible;
		// Only available if alpha level is high enough
		if (visible)
			available = (alphaLevel > ALPHA_BLOCK);
		else
			available = false;
		// If this control has children than make them available if this control
		// is visible and unavailable if invisible
		if (children != null) {
			for (GAbstractControl c : children)
				c.setAvailable(this.visible);
		}
	}

	/**
	 * @return the control's visibility
	 */
	public boolean isVisible() {
		return visible;
	}

	/**
	 * The availability flag is used by the library code to determine whether a
	 * control should be considered for drawing and mouse/key input. <br>
	 * It permits an internal control that does not affect the visible and enabled
	 * state of the control, which are set by the programmer.
	 * 
	 * If a control and its children are made unavailable it will still be drawn but
	 * it not respond to user input.
	 * 
	 * @param avail
	 */
	protected void setAvailable(boolean avail) {
		available = avail;
		if (children != null) {
			for (GAbstractControl c : children)
				c.setAvailable(avail);
		}
	}

	/**
	 * Is this control available?
	 */
	protected boolean isAvailable() {
		return available;
	}

	/**
	 * Determines whether to show the back colour or not. Only applies to some
	 * controls
	 * 
	 * @param opaque true = opaque, flase = transparent
	 */
	public void setOpaque(boolean opaque) {
		// Ensure that we dont't go from true >> false otherwise
		// it will validate an invalid buffer
		bufferInvalid |= (opaque != this.opaque);
		this.opaque = opaque;
	}

	/**
	 * Find out if the control is opaque
	 * 
	 * @return true if the background is visible
	 */
	public boolean isOpaque() {
		return opaque;
	}

	public boolean isDragging() {
		return dragging;
	}

	/**
	 * Enable or disable the ability of the control to generate mouse events.<br>
	 * GTextField - it also controls key press events <br>
	 * GPanel - controls whether the panel can be moved/collapsed/expanded <br>
	 * 
	 * @param enable true to enable else false
	 */
	public void setEnabled(boolean enable) {
		enabled = enable;
		if (children != null) {
			for (GAbstractControl c : children)
				c.setEnabled(enable);
		}
	}

	/**
	 * Is this control enabled
	 * 
	 * @return true if the control is enabled
	 */
	public boolean isEnabled() {
		return enabled;
	}

	/**
	 * Give the focus to this control but only after allowing the current control
	 * with focus to release it gracefully. <br>
	 * Always cancel the keyFocusIsWith irrespective of the control type. If the
	 * control needs to retain keyFocus then override this method in that class e.g.
	 * GCombo
	 */
	protected void takeFocus() {
		if (focusIsWith != null && focusIsWith != this)
			focusIsWith.loseFocus(this);
		focusIsWith = this;
	}

	/**
	 * For most controls there is nothing to do when they loose focus. Override this
	 * method in classes that need to do something when they loose focus eg
	 * TextField
	 */
	protected void loseFocus(GAbstractControl grabber) {
		if (cursorIsOver == this)
			cursorIsOver = null;
		focusIsWith = grabber;
		bufferInvalid = true;
	}

	/**
	 * Determines whether this control is to have focus or not
	 * 
	 * @param focus true if the control is to have focus else false.
	 */
	public void setFocus(boolean focus) {
		if (focus)
			takeFocus();
		else
			loseFocus(parent);
	}

	/**
	 * Does this control have focus
	 * 
	 * @return true if this control has focus else false
	 */
	public boolean hasFocus() {
		return (this == focusIsWith);
	}

	/**
	 * Get the Z order value for the object with focus. <br>
	 * If there is no object with focus or the focus is with a control on another
	 * window then return -1 which will allow this control to take focus. <br>
	 */
	protected int focusObjectZ() {
		return focusIsWith == null || focusIsWith.getPApplet() != getPApplet() ? -1 : focusIsWith.z;
	}

	/**
	 * 
	 * All addControl(...) methods must call this one. <br>
	 * 
	 * Checks to see if this control allows children and creates the child list if
	 * needed. <br>
	 * 
	 * @param c     the control to add.
	 * @param x     the leftmost or centre position depending on controlMode
	 * @param y     the topmost or centre position depending on controlMode
	 * @param angle the rotation angle (replaces any the angle specified in control)
	 */
	protected void addControlImpl(GAbstractControl c, float x, float y, float angle) {
		if (!allowChildren) {
			System.err.println("Controls cannot be added to " + this.getClass().getSimpleName() + "(s)!");
			return;
		}
		if (children == null)
			children = new LinkedList<GAbstractControl>();
		// return;
		c.rotAngle = angle;
		// In child control reset the control so it centred about the origin
		AffineTransform aff = new AffineTransform();
		aff.setToRotation(angle);
		/*
		 * The following code should result in the x,y and cx, cy coordinates of the
		 * added control (c) added being measured relative to the centre of this
		 * control.
		 */
		switch (G4P.control_mode) {
		case CORNER:
		case CORNERS:
			// Rotate about top corner
			c.x = x;
			c.y = y;
			c.temp[0] = c.halfWidth;
			c.temp[1] = c.halfHeight;
			aff.transform(c.temp, 0, c.temp, 0, 1);
			c.cx = (float) c.temp[0] + x - halfWidth;
			c.cy = (float) c.temp[1] + y - halfHeight;
			c.x = c.cx - c.halfWidth;
			c.y = c.cy - c.halfHeight;
			break;
		case CENTER:
			// Rotate about centre
			c.cx = x;
			c.cy = y;
			c.temp[0] = -c.halfWidth;
			c.temp[1] = -c.halfHeight;
			aff.transform(c.temp, 0, c.temp, 0, 1);
			c.x = c.cx + (float) c.temp[0] - halfWidth;
			c.y = c.cy - (float) c.temp[1] - halfHeight;
			c.cx -= halfWidth;
			c.cy -= halfHeight;
			break;
		}
		c.rotAngle = angle;
		// Add to parent
		c.parent = this;
		c.setZ(z);
		// Parent will now be responsible for drawing
		c.registeredMethods &= (ALL_METHOD - DRAW_METHOD);
		children.addLast(c);
		Collections.sort(children, new Z_Order());
		// Does the control being added have to do anything extra
		c.addToParent(this);
	}

	/**
	 * This will set the rotation of the control to angle overwriting any previous
	 * rotation set. Then it calculates the centre position so that the original top
	 * left corner of the control will be the position indicated by x,y with respect
	 * to the top left corner of parent. <br>
	 * 
	 * The added control will have its position calculated relative to the centre of
	 * the parent control. <br>
	 * 
	 * All overloaded methods call this one. <br>
	 * 
	 * @param c     the control to add.
	 * @param x     the leftmost or centre position depending on controlMode
	 * @param y     the topmost or centre position depending on controlMode
	 * @param angle the rotation angle (replaces any the angle specified in control)
	 */
	public void addControl(GAbstractControl c, float x, float y, float angle) {
		addControlImpl(c, x, y, angle);
	}

	/**
	 * Add a control at the given position with zero rotation angle.
	 * 
	 * @param c the control to add.
	 * @param x the leftmost or centre position depending on controlMode
	 * @param y the topmost or centre position depending on controlMode
	 */
	public void addControl(GAbstractControl c, float x, float y) {
		addControlImpl(c, x, y, 0);
	}

	/**
	 * Add a control at the position and rotation specified in the control.
	 * 
	 * @param c the control to add
	 */
	public void addControl(GAbstractControl c) {
		switch (G4P.control_mode) {
		case CORNER:
		case CORNERS:
			addControlImpl(c, c.x, c.y, c.rotAngle);
			break;
		case CENTER:
			addControlImpl(c, c.cx, c.cy, c.rotAngle);
			break;
		}
	}

	/**
	 * Add several control at the position and rotation specified in each control.
	 * 
	 * @param controls comma separated list of controls
	 */
	public void addControls(GAbstractControl... controls) {
		for (GAbstractControl c : controls) {
			switch (G4P.control_mode) {
			case CORNER:
			case CORNERS:
				addControlImpl(c, c.x, c.y, c.rotAngle);
				break;
			case CENTER:
				addControlImpl(c, c.cx, c.cy, c.rotAngle);
				break;
			}
		}
	}

	/**
	 * Changes that need to be made to child when added. Override where needed e.g.
	 * GPanel
	 * 
	 * @param p the parent
	 */
	protected void addToParent(GAbstractControl p) {
	}

	/**
	 * Get the shape type when the cursor is over a control
	 * 
	 * @return shape type
	 */
	public int getCursorOver() {
		return cursorOver;
	}

	/**
	 * Set the shape type to use when the cursor is over a control
	 * 
	 * @param cursorOver the shape type to use
	 */
	public void setCursorOver(int cursorOver) {
		this.cursorOver = cursorOver;
	}

	/**
	 * Get an affine transformation that is the compound of all transformations
	 * including parents
	 * 
	 * @param aff
	 */
	protected AffineTransform getTransform(AffineTransform aff) {
		if (parent != null)
			aff = parent.getTransform(aff);
		aff.translate(cx, cy);
		aff.rotate(rotAngle);
		return aff;
	}

	/**
	 * This method takes a position px, py and calculates the equivalent position
	 * [ox,oy] as if no transformations have taken place and the origin is the
	 * top-left corner of the control.
	 * 
	 * @param px
	 * @param py
	 */
	protected void calcTransformedOrigin(float px, float py) {
		AffineTransform aff = new AffineTransform();
		aff = getTransform(aff);
		temp[0] = px;
		temp[1] = py;
		try {
			aff.inverseTransform(temp, 0, temp, 0, 1);
			ox = (float) temp[0] + halfWidth;
			oy = (float) temp[1] + halfHeight;
		} catch (NoninvertibleTransformException e) {
		}
	}

	/**
	 * Recursive function to set the priority of a control. This is used to
	 * determine who gets focus when controls overlap on the screen e.g. when a
	 * droplist expands it might cover a button. <br>
	 * It is used where controls have childen e.g. GDropList and GPaneln It is used
	 * when a child control is added.
	 * 
	 * @param control
	 * @param parentZ
	 */
	protected void setZ(int parentZ) {
		z += parentZ;
		if (children != null) {
			for (GAbstractControl c : children) {
				c.setZ(parentZ);
			}
		}
	}

	public String toString() {
		if (tag == null)
			return this.getClass().getSimpleName();
		else
			return tag;
	}

	/**
	 * Comparator used for controlling the order controls are drawn
	 * 
	 * @author Peter Lager
	 */
	public static class Z_Order implements Comparator<GAbstractControl> {

		public int compare(GAbstractControl c1, GAbstractControl c2) {
			if (c1.z != c2.z)
				return new Integer(c1.z).compareTo(new Integer(c2.z));
			else
				return new Integer((int) -c1.y).compareTo(new Integer((int) -c2.y));
		}

	} // end of comparator class

}
